<body class="view jarallax" data-jarallax='{"speed": 0.2}' style="background-image: url('/img/error/page-not-found.gif'); background-repeat: no-repeat; background-size:80%; background-position: center; background-color: #FCC800; margin-top: -200px; position: relative;">
    <h2>Back To <a href="/"><img src="{{ asset('img/error/home.png') }}" alt="Home"> Please ..</a></h2>
</body>

<style>
    .jarallax {
      height: 100vh;
    }

    h2{
        text-align: center;
        bottom: -5%;
        max-width: 640px;s
        left: 0;
        right: 0;
        margin: auto;
        position: absolute;
    }

    h2 a{
        color: black;
        font-style: italic;
    }

    h2 img{
        width: 10%;
        margin-bottom: -25px;
    }
</style>
