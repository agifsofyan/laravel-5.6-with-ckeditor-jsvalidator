<script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>
{{-- Post --}}
{!! JsValidator::formRequest('App\Http\Requests\PostRequest', '#save-post') !!}
{!! JsValidator::formRequest('App\Http\Requests\PostUdateRequest', '#save-Upost') !!}
{{-- Page --}}
{!! JsValidator::formRequest('App\Http\Requests\PageRequest', '#save-page') !!}
{!! JsValidator::formRequest('App\Http\Requests\PageUpdateRequest', '#save-Upage') !!}
{{-- Category --}}
{!! JsValidator::formRequest('App\Http\Requests\CategoryRequest', '#save-cate') !!}
{!! JsValidator::formRequest('App\Http\Requests\CategoryUpdateRequest', '#save-Ucate') !!}

<script>
    CKEDITOR.replace('my-editor',{
        filebrowserImageBrowseUrl: '/andrologi-filemanager?type=Images',
        filebrowserImageUploadUrl: '/andrologi-filemanager/upload?type=Images&_token={{csrf_token()}}',
        filebrowserBrowseUrl: '/andrologi-filemanager?type=Files',
        filebrowserUploadUrl: '/andrologi-filemanager/upload?type=Files&_token={{csrf_token()}}'
    });
    CKEDITOR.config.allowedContent = true;
</script>

{{--  Toggle Sidebar  --}}
<script>
    $(document).ready(function () {

        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });

    });
</script>

{{-- confirm delete --}}
<script type="text/javascript">
    $('.delete-btn').on('click', function(e){
        e.preventDefault();
        var self   = $(this);
        var title  = $(this).attr("data-postTitle");
        var formid = $(this).attr("data-postId");
        swal({
            title: "Konfirmasi",
            text:  "Hapus Data : "+title+" ?",
            type:  "warning",
            showCancelButton: true,
            confirmButtonClass: "btn btn-outline-danger waves-effect",
            cancelButtonClass: "btn btn-elegant waves-effect",
            confirmButtonText:  "Ya, Hapus !",
            cancelButtonText:  "Batal",
            closeConfirm: true
        },function(){
            $("#"+formid).submit();
        });
    });
</script>

<script>
    document.getElementById("chat").onclick = function() {
        window.location.href = "https://mqa.zoosnet.net/LR/Chatpre.aspx?id=MQA87261512&lng=en";
</script>
