"Halaman ini telah diakses sebanyak ". $total_access . "kali."
