{{--  <br><br>  --}}
{{--  <footer class="page-footer font-small blue-grey lighten-5">

    <div class="card fixed-bottom" style="background-color: #7386D5;">
        <div class="card-body text-center" style="width: 100%;">
            Footer
        </div>
    </div>
</footer>  --}}
</div></div>
