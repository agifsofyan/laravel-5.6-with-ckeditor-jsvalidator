@extends('admin.main')

@section('title', '| Categories')

@section('content')

	<div class="container">

		{{-- Check if current user is logged-in or a guest --}}
		@if (Auth::guest())

			<p class="mt-5">Who are you ?, please <a href="/login/">login</a> to continue.</p>

		@else

			<div class="blog-header">
		        <h1 class="blog-title">Categories <a class="btn btn-sm btn-primary" href="{{ route('categories.create') }}">Add New</a></h1>
            </div>

            @include('alert.toast')

			<div class="container-fluid">
				<div>

					<table class="table">
						<tr class="row">
							<th class="col-4">Title</th>
							<th class="col-4">Date</th>
							<th class="col-4">action</th>
						</tr>
						<tr>
							{{-- Blade if and else --}}
							@if( $categories )
								{{-- Blade foreach --}}
								@foreach( $categories as $category )
									<tr class="row">
										<td class="col-4">
											<strong>
												<a href="{{ route('categories.edit', $category->id) }}">
													{{ $category->category_name }}
												</a>
											</strong>
										</td>
										<td class="col-4">Published {{ date( 'j/m/Y', strtotime( $category->created_at ) ) }}</td>
										<td class="col-4">
											<div class="row">
												<div class="6">
													<a class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modalConfirmDelete"/><i class="fa fa-trash" aria-hidden="true"></i> </a>
												</div>
												<div class="6">
													<a class="btn btn-sm btn-info" href="{{ route('categories.edit', $category->id) }}"><i class="fa fa-pencil" aria-hidden="true"></i></a>
												</div>
											</div>
                                        </td>
									</tr>
								@endforeach
							@endif
						</tr>
					</table>

                    <div class="d-flex justify-content-center">{{ $categories->links() }}</div>

				</div>
			</div>

		@endif

	</div>

	{{-- Modal for delete --}}
    <!--Modal: modalConfirmDelete-->
	<div class="modal fade" id="modalConfirmDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
			<!--Content-->
			<div class="modal-content text-center">
				<!--Header-->
				<div class="modal-header d-flex justify-content-center">
					<p class="heading">Are you sure?</p>
				</div>

				<!--Body-->
				<div class="modal-body">
					<i class="fa fa-times fa-4x animated rotateIn"></i>
				</div>

				<!--Footer-->
				<div class="modal-footer flex-center">
					<form class="d-inline delete" action="{{ route('categories.destroy', $category->id) }}" method="POST">
				    	{{ csrf_field() }}
				        {{ method_field('DELETE') }}

				        <button type="submit" class="btn btn-sm btn-outline-danger"/>Ya</button>
				    </form>

				    <a type="button" class="btn btn-sm btn-elegant waves-effect" data-dismiss="modal">No</a>
				</div>
			</div>
			<!--/.Content-->
		</div>
	</div>
	<!--Modal: modalConfirmDelete-->

@endsection
