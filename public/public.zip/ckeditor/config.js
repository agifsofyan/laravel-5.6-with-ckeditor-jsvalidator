/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	config.language = 'id';
    // config.uiColor = '#cfd8dc';
    config.toolbarCanCollapse = true;
};

// CKEDITOR.replace('my-editor');
// $(document).ready(function(){

//    $("#save-admin").validate({
//    ignore: [],

//      rules:{
//      		firstname:{
//         	required:true
//         },
//     editor1: {
//        required: function(textarea) {
//        CKEDITOR.instances[textarea.id].updateElement();
//        var editorcontent = textarea.value.replace(/<[^>]*>/gi, '');
//        return editorcontent.length === 0;
//      }
//                }
//      },messages:{
//      		firstname:{
//         	required:"Enter first name"
//         }

//      }
//    });

// });
