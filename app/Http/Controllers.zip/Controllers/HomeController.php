<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;

class HomeController extends Controller
{
    public function index(){
        return view('pages.index');
    }
    // Access Log
    public function logTest(Request $request)
    {
        $total_access = DB::table('access_logs')->where('path', $request->path())->count();
        return "Halaman ini telah diakses sebanyak ". $total_access . "kali.";
    }
}
